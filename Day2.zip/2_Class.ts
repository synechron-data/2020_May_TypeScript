// class Employee {
//     private _name: string;

//     // Multiple constructor implementations are not allowed.
//     // constructor() {
//     //     this._name = "NA";
//     // }

//     // constructor(name:string) {
//     //     this._name = name;
//     // }

//     constructor(name = "NA") {
//         this._name = name;
//     }

//     getName() {
//         return this._name;
//     }

//     // Never use Lambda to create member functions, it will increase the memory usage
//     // getName = () => {
//     //     return this._name;
//     // }

//     setName(name: string) {
//         this._name = name;
//     }
// }

// // var e1 = new Employee();
// var e1 = new Employee("Abhijeet");
// console.log(e1.getName());
// e1.setName("Manish");
// console.log(e1.getName());

// ------------------------------------------------------------ Property

// class Employee {
//     private _name: string;
//     private _age: number;

//     constructor(name = "NA", age = 0) {
//         this._name = name;
//         this._age = age;
//     }

//     get Name() {
//         return this._name;
//     }

//     set Name(name: string) {
//         this._name = name;
//     }

//     get Age() {
//         return this._age;
//     }

//     set Age(value: number) {
//         this._age = value;
//     }
// }

// var e1 = new Employee("Abhijeet");
// console.log(e1.Name);
// console.log(e1.Age);
// e1.Name = "Manish";
// e1.Age = 38;
// console.log(e1.Name);
// console.log(e1.Age);

// -------------------------------------- Parameter (Properties/Members)
// Parameter properties let us create and initialize member variables in one place. 
// It is a shorthand for creating member variables.

// class Employee {
//     constructor(private _name = "NA", private _age = 0) { }

//     get Name() {
//         return this._name;
//     }

//     set Name(name: string) {
//         this._name = name;
//     }

//     get Age() {
//         return this._age;
//     }

//     set Age(value: number) {
//         this._age = value;
//     }
// }

// var e1 = new Employee("Abhijeet");
// console.log(e1.Name);
// console.log(e1.Age);
// e1.Name = "Manish";
// e1.Age = 38;
// console.log(e1.Name);
// console.log(e1.Age);

// // ---------------------------------------------- Static Members
// class BankAccount {
//     private static _bankName: string;

//     constructor(private _accName: string) { }

//     get BankName(): string {
//         return BankAccount._bankName;
//     }

//     static set BankName(value: string) {
//         BankAccount._bankName = value;
//     }

//     get AccountName(): string {
//         return this._accName;
//     }
// }

// BankAccount.BankName = "ICICI";

// var a1 = new BankAccount("Manish");
// console.log("Bank Name: ", a1.BankName);
// console.log("Account Holder Name: ", a1.AccountName);

// var a2 = new BankAccount("Abhijeet");
// console.log("Bank Name: ", a2.BankName);
// console.log("Account Holder Name: ", a2.AccountName);

// ---------------------------------------------- ReadOnly 
class BankAccount {
    private static _bankName: string;

    constructor(private readonly _accNumber: number, private _accName: string) { }

    get BankName(): string {
        return BankAccount._bankName;
    }

    static set BankName(value: string) {
        BankAccount._bankName = value;
    }

    get AccountName(): string {
        return this._accName;
    }

    get AccountNumber(): number {
        // this._accNumber = 100;
        return this._accNumber;
    }
}

BankAccount.BankName = "ICICI";

var a1 = new BankAccount(1, "Manish");
// a1.BankName = "ICICI";
console.log("Bank Name: ", a1.BankName);
console.log("Account Number: ", a1.AccountNumber);
console.log("Account Holder Name: ", a1.AccountName);

var a2 = new BankAccount(2, "Abhijeet");
console.log("Bank Name: ", a2.BankName);
console.log("Account Number: ", a2.AccountNumber);
console.log("Account Holder Name: ", a2.AccountName);