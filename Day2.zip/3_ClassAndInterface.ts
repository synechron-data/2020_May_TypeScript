// interface IPerson {
//     name: string;
//     age: number;
//     greet: (message: string) => string;
// }

// class Person implements IPerson {
//     name: string;
//     age: number;

//     constructor(n: string, a: number) {
//         this.name = n;
//         this.age = a;
//     }

//     greet(message: string): string {
//         return "Hello";
//     }
// }

// let p1: IPerson = new Person("Abhijeet", 38)
// console.log(p1.greet("Hi"));

// let p2: IPerson = new Person("Ramakant", 38)
// console.log(p2.greet("Hi"));

// ------------------------------------------------------ Multiple Interface Implementation

// interface IPerson {
//     name: string;
//     age: number;
//     greet: (message: string) => string;
// }

// interface IWork {
//     doWork(): string;
// }

// class Person implements IPerson, IWork {
//     name: string;
//     age: number;

//     constructor(n: string, a: number) {
//         this.name = n;
//         this.age = a;
//     }

//     greet(message: string): string {
//         return "Hello";
//     }

//     doWork(): string {
//         return "I am learning typescript";
//     }
// }

// let p1: Person = new Person("Abhijeet", 38)
// console.log(p1.greet("Hi"));
// console.log(p1.doWork());

// ------------------------------------------------------ Interface can extend other Interfaces

// interface IPerson {
//     name: string;
//     age: number;
//     greet: (message: string) => string;
// }

// interface IWork {
//     doWork(): string;
// }

// interface ICustomer extends IPerson, IWork {
//     doShopping(): string;
// }

// class Person implements IPerson, IWork, ICustomer {
//     name: string;
//     age: number;

//     constructor(n: string, a: number) {
//         this.name = n;
//         this.age = a;
//     }

//     greet(message: string): string {
//         return "Hello";
//     }

//     doWork(): string {
//         return "I am learning typescript";
//     }

//     doShopping(): string {
//         return "Let's do it online";
//     }
// }

// // let p1: Person = new Person("Abhijeet", 38);
// // console.log(p1.greet("Hi"));
// // console.log(p1.doWork());
// // console.log(p1.doShopping());

// // let p1: IPerson = new Person("Abhijeet", 38);
// // console.log(p1.greet("Hi"));

// // let p2: IWork = new Person("Abhijeet", 38);
// // console.log(p2.doWork());

// let p3: ICustomer = new Person("Abhijeet", 38);
// console.log(p3.greet("Hi"));
// console.log(p3.doWork());
// console.log(p3.doShopping());

// ------------------------------------------------------- Interface can extend from class (s)

// class Vehicle {
//     constructor(public make: string) { }

//     getMake() {
//         return this.make;
//     }
// }

// class Engine {
//     constructor(public make: string, public manufacturer: string) { }

//     getMake() {
//         return this.make;
//     }

//     getManufacturer() {
//         return this.manufacturer;
//     }
// }

// interface IVehicle extends Vehicle, Engine { }

// class FourWheeler implements IVehicle {
//     public make: string;
//     public manufacturer: string;

//     getMake(): string {
//         throw new Error("Method not implemented.");
//     }

//     getManufacturer(): string {
//         throw new Error("Method not implemented.");
//     }
// }