function getLength(arg) {
    return arg.reverse();
}
console.log(getLength(["Manish", "Abhijeet"]));
console.log(getLength([10, 20, 30, 40, 50]));
