// Generics allows you to create a component that can work over a variety of types 
// rather than a single one, without loosing type safety and intellisense

// class Queue {
//     private _data: number[] = [];

//     push(d: number) {
//         this._data.push(d);
//     }

//     pop(): number {
//         return this._data.shift();
//     }
// }

// var numberQ = new Queue();

// numberQ.push(10);
// numberQ.push(20);
// numberQ.push(30);

// console.log(numberQ.pop());
// console.log(numberQ.pop());
// console.log(numberQ.pop());

// ------------------------------------------------------- Flexibility, we can use 'any' as a type
// class Queue {
//     private _data: any[] = [];

//     push(d: any) {
//         this._data.push(d);
//     }

//     pop(): any {
//         return this._data.shift();
//     }
// }

// var numberQ = new Queue();

// numberQ.push(10);
// numberQ.push(20);
// numberQ.push(30);

// console.log(numberQ.pop());
// console.log(numberQ.pop());
// console.log(numberQ.pop());

// var stringQ = new Queue();

// stringQ.push("abc");
// stringQ.push("xyz");
// stringQ.push("qwerty");

// console.log(stringQ.pop());
// console.log(stringQ.pop());
// console.log(stringQ.pop());

// ------------------------------------------------------- Generics
// class Queue<T>  {
//     private _data: T[] = [];

//     push(d: T) {
//         this._data.push(d);
//     }

//     pop(): T {
//         return this._data.shift();
//     }
// }

// var numberQ = new Queue<number>();

// numberQ.push(10);
// numberQ.push(20);
// numberQ.push(30);

// console.log(numberQ.pop().toFixed());
// console.log(numberQ.pop());
// console.log(numberQ.pop());

// var stringQ = new Queue<string>();

// stringQ.push("abc");
// stringQ.push("xyz");
// // var a: any = 10;
// // stringQ.push(a);
// // stringQ.push(10);
// stringQ.push("qwerty");

// console.log(stringQ.pop().toUpperCase());
// console.log(stringQ.pop().toUpperCase());
// console.log(stringQ.pop().toUpperCase());

// ------------------------------------------------------------- Constraints 
interface ILength {
    length: number;
    reverse(): any[];
}

function getLength<T extends ILength>(arg: T) {
    return arg.reverse();
}

// console.log(getLength<string>("Manish"));
console.log(getLength<string[]>(["Manish", "Abhijeet"]));
console.log(getLength<number[]>([10, 20, 30, 40, 50]));

// console.log(getLength<number>(10));