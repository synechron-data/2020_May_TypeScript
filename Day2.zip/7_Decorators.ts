// Types of Decorators
// Class Decorator <T extends Function>(target:T) => T | void
// Property Decorator (target: Object, propertyKey: string | symbol) => void;
// Method Decorator <T>(target: Object, propertyKey: string | symbol, descriptor: TypedPropertyDescriptor<T>) => TypedPropertyDescriptor<T> | void;
// Parameter Decorator (target: Object, propertyKey: string | symbol, parameterIndex: number) => void;

// function log<T>(target: T, propertyKey: string, descriptor: any) {
//     var originalMethod = descriptor.value;

//     descriptor.value = function (...args: any[]) {
//         var fn_args = args.map(arg => JSON.stringify(arg)).join();
//         console.log(`${propertyKey} is called with arguments as ${fn_args}`);
//         var result = originalMethod.apply(this, args);
//         return result;
//     }

//     return descriptor;
// }

// class Calculate {
//     @log
//     add(x: number, y: number) {
//         return x + y;
//     }

//     @log
//     sub(x: number, y: number) {
//         return x - y;
//     }
// }

// var c = new Calculate();
// console.log(c.add(23, 45));
// console.log(c.sub(2, 4));

// ---------------------------------------------------------

// function CityDecorator<T extends { new(...args: any[]): {} }>(target: T) {
//     return class extends target {
//         city = "Pune";
//         display = function () {
//             return JSON.stringify(this);
//         }
//     }
// }

function CityDecorator(obj: { cityName: string }) {
    return function <T extends { new(...args: any[]): {} }>(target: T) {
        return class extends target {
            city = obj.cityName;
            display = function () {
                return JSON.stringify(this);
            }
        }
    }
}

@CityDecorator({
    cityName: "Mumbai"
})
class MyPerson {
    name: string;

    constructor(n = "NA") {
        this.name = n;
    }
}

// console.log(new MyPerson("Manish"));
// console.log(JSON.stringify(new MyPerson("Manish")));

var p: any = new MyPerson("Manish");
console.log(p.display());


// @Component({}), @NgModule({})   - Class
// @Inject()                       - Parameter
// @Input()                        - Property
// @HostListener()                 - Method